﻿using EmpLib;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Emplib
{
    public class emputils
    {
        public static List<Employee> empdb {  get; set; } = new List<Employee>();
        public static List<Employee> empnew { get; set; } = new List<Employee>();
        public static int EmpCount { get; set; }
        public static void log<T>(T[] pvalues)
        {
            string result = ",";
            foreach (var item in pvalues)
            {
                result = $"{result} {item}";
            }

            var finalResult = $"[{DateTime.Now.ToString()}] : {result}";

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("...............");
            Console.WriteLine(finalResult);


            //outputwindow
            Debug.WriteLine("--------------log-------------");
            Debug.WriteLine(finalResult);
        }

        public static object Where(Func<object, bool> value)
        {
            throw new NotImplementedException();
        }
    }
}
