﻿// See https://aka.ms/new-console-template for more information
//f1();
using System.Diagnostics;

void f1()
{
    Console.WriteLine("Hello, World!");
    int num1 = 100;
    int num2 = 100;
    Console.WriteLine("sum= " + (num1 + num2));

    var num3 = 200;
    var formattedFloat = 200f;
    var formatteddouble = 200d;
    var formattedDecimal = 3200m;
    Console.WriteLine(num3.GetType().Name);
    Console.WriteLine(formattedFloat.GetType().Name);
    Console.WriteLine(formatteddouble.GetType().Name);
    Console.WriteLine(formattedDecimal.GetType().Name);

    Console.WriteLine($"the datatype of num3 is {num3.GetType().Name}");


    bool isEverythingOK = true;
    string greetMessage = "Hello welcome to C# training session";
    char iamSingle = 'S';

    Console.WriteLine($"value of {nameof(isEverythingOK)} {isEverythingOK}");
}


void Working()
{
    int num1 = 100;
    double nume2 = 100;
    bool isEverythingOK = true;
    string str = "hello";
    string strNum = "100";

    var result1 = (double)num1;
    var result2 = (int)nume2;


    var convert1 = Convert.ToString(num1);
    var convert2 = Convert.ToString(nume2);

}
//Working();

void workingwitharrays()

{
    int[] arr = new int[3];
    arr[0] = 10;
    arr[1] = 20;
    arr[2] = 30;
    for (int i = 0; i < arr.Length; i++)
    {
        Console.WriteLine($"Value of item : {arr[i]}");
    }

    string[] greetings = { "Namasthe", "hello", "hola" };
    int counter = 0;
    while (counter <= greetings.Length)
    {
        Console.WriteLine($"A new way to greet: {greetings[counter]}");
        counter++;
    }
    int[] evens = { 2, 4, 6, 8, 10 };
    counter = 0;
    do
    {
        Console.WriteLine($"the next even number: {evens[counter]}");
        counter++;

    } while (counter <= evens.Length);



    object[] objArray = { 100, "Ok", new int[] { 1, 2, 3 } };

    foreach (var item in (Int32[])objArray[2])
    {
        Console.WriteLine(item);
    }


    object[] objArray1 = { 100, "Ok", new int[] { 1, 2, 3 } };
    foreach (var singleitem in objArray1)
    {
        if (singleitem.GetType().Name == "Int32[]")
        {
            foreach (var item in (Int32[])singleitem)
            {
                Console.WriteLine(item);
            }
        }
        else
        {
            Console.WriteLine(singleitem);
        }
    }
}

//workingwitharrays();

void workingwithcollections()
{
    List<string> shoppinglist = new List<string>();
    Console.WriteLine($"total items is shopping bag:  {shoppinglist.Count()}");
    shoppinglist.Add("Bags");
    log(new object[] { "item added: ", shoppinglist[0] });
    shoppinglist.Add("Dresses");

    log(new object[] { "item added: ", shoppinglist[1] });
    shoppinglist.Add("shoes");

    log(new object[] { "item added: ", shoppinglist[2] });
    //print
    PrintValues(shoppinglist);

    Console.WriteLine($"total time in shopping bag: {shoppinglist.Count()}");
    shoppinglist.Remove("shoes");

    log(new object[] { "item removed: ", "shoes" });
    Console.WriteLine($"total times in shopping bag: {shoppinglist.Count()}");
    ///
    print(new object[]
    {"csv os shopping list",shoppinglist[0],shoppinglist[1], "\n the total count is:\t",shoppinglist.Count() });

    }






void PrintValues<T>(List<T> pCollection)

{
    foreach(var item in pCollection)
    {
        Console.WriteLine(item);
    }
}

void print(object[] pvalues)
{
    string result = " ";
    foreach (var item in pvalues)
    {
        result = $"(result),(item)";
    }
    result = result.TrimStart(',');
    Console.WriteLine(result);
}
void log(object[] pvalues)
{
    string result = ",";
    foreach (var item in pvalues)
    {
        result = $"{result} {item}";
    }

    var finalResult = $"[{DateTime.Now.ToString()}] : {result}";

    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("...............");
    Console.WriteLine(finalResult);


    //outputwindow
    Debug.WriteLine("--------------log-------------");
    Debug.WriteLine(finalResult);
}
//
workingwithcollections();

