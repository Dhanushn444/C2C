using EmpLib;

namespace empforms
{
    public partial class Form1 : Form
    {
        Employee kpmgemp = new Employee();
        Employee kpmgresign = new Employee();
        public Form1()
        {
            InitializeComponent();
            button1.Click += Button1_Click2;
            button1.Click += Button1_Click3;
            kpmgemp.join += Sri_join;
            kpmgemp.join += Rohith_join;
            kpmgemp.join += Lekha_join;

            button2.Click += kpmgemp_join;


            button3.Click += kpmgresign_resign;
            kpmgresign.resign += sri_resign;
            kpmgresign.resign += lekha_resign;



        }



        private void kpmgresign_resign(object? sender, EventArgs e)
        {

            MessageBox.Show("SRI resigned KPMG successfully");
        }

        private void lekha_resign(object? sender, EventArgs e)
        {
            MessageBox.Show("lekha resigned KPMG successfully");
        }

        private void sri_resign(object? sender, EventArgs e)
        {
            MessageBox.Show("sri resigned KPMG successfully");
        }





        private void Lekha_join(object? sender, EventArgs e)
        {
            MessageBox.Show("Lekha JOINED KPMG successfully");
        }

        private void Rohith_join(object? sender, EventArgs e)
        {
            MessageBox.Show("rohith JOINED KPMG successfully");
        }

        private void Sri_join(object? sender, EventArgs e)
        {

            MessageBox.Show("SRI JOINED KPMG successfully");
        }
        private void kpmgemp_join(object? sender, EventArgs e)
        {

            MessageBox.Show("SRI JOINED KPMG successfully");
        }


        private void Button1_Click2(object? sender, EventArgs e)
        {
            MessageBox.Show("you clicked the button twice");
        }

        private void Button1_Click3(object sender, EventArgs e)
        {
            MessageBox.Show("you clicked the button thrice");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("you clicked the button");

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            kpmgemp.TriggerjoinEvent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            kpmgresign.TriggerresignEvent();
        }
    }
}