﻿using Emplib;
using EmpLib;
using System;


Person Rohith = new Person();
Rohith.Name = "Rohith";
Console.WriteLine(Rohith.Eat());

Person Rana = new Person();
Rana.Name = "Rana";
Console.WriteLine(Rana.Sleep());

Person Baap = new Employee() { Designation = "Intern", DOJ = DateTime.Now.AddMonths(-1) };
Baap.Name = "Baap";
((Employee)Baap).Designation = "Analyst";
Console.WriteLine(Baap.Work());
Console.WriteLine($"EmpId for {Baap.Name} is {((Employee)Baap).EmpId}");

Console.WriteLine(((Employee)Baap).AttendTraining("C2C"));

//polymorphism
RuntimePolymorphism Sharmaji = new RuntimePolymorphism();
Console.WriteLine($"Sharmaji:{Sharmaji.Settle()}");
Console.WriteLine($"Sharmaji gets married:{Sharmaji.GetMarried()}");

RuntimePolymorphism SharmajiKaBeta = new RuntimePolymorphism();
Console.WriteLine($"Sharmaji:{SharmajiKaBeta.Settle()}");
Console.WriteLine($"Sharmaji gets married:{SharmajiKaBeta.GetMarried()}");

RuntimePolymorphism SharmaJiKaBeta2 = new Child();
Console.WriteLine($"SharmajiKaBeta2 gets married:{((Child)SharmaJiKaBeta2).GetMarried()}");
Console.WriteLine($"Sharmaji ka drawing concept (Using Abstract):{Sharmaji.Drawing()}");
Console.WriteLine($"Sharmaji ka dating concept (Using Abstract):{Sharmaji.WhatIsDating()}");

Employee Vidya = new Employee();
Vidya.Name = "Vidya";
Vidya.Designation = "Hacking";
Console.WriteLine(Vidya.Work());
Console.WriteLine(Vidya.Work("Hacking websites"));


Employee Srikar = new Employee();
Srikar.Name = "Srikar";
Srikar.SetTaxInfo("Im eligible in the 20% tax payer category");
Console.WriteLine(Srikar.GetTaxInfo());
Person SriRam = new Person("ASFSD79878765", "+91 9876543210");

Console.WriteLine($"Aadhar:{SriRam.Aadhar}| Mobile Number:{SriRam.Mobile}");
Console.WriteLine($"total no of employees is :{emputils.EmpCount}");
emputils.empdb.Add(Srikar);
emputils.empdb.Add(Vidya);
emputils.empdb.Add(new Employee("adads83838838", "+91 2828291192") { Name = "Nidha", Designation = "Analyst", Salary = 60000 });
emputils.empdb.Add(new Employee("baba83838838", "+91 4548291192") { Name = "loki", Designation = "Analyst", Salary = 70000 });

var resultList = emputils.empdb.Where((emp) => emp.Aadhar != null && emp.Aadhar.StartsWith("AA"));
resultList.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name }|{emp.Aadhar}|{emp.Designation}"));
// get all employees with salary greater that 6L
var resultList1 = emputils.empdb.Where((emp) => emp.Salary != null && emp.Salary>=600000);
resultList.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name}|{emp.Aadhar}|{emp.Designation}"));


