﻿namespace demon;

public class Class1
{

}
