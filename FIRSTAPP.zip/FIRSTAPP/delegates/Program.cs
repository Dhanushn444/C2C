﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;
using System.Runtime.CompilerServices;

partial class Program
{
    private static object a;

    delegate void Compute(int n1, int n2);
    delegate void Contractor(double budget);
    delegate void work(string a,bool b);


    static void Main()
    {
        Action<string,bool> working = new Action<string,bool>(
           (a,b) =>
           {
               Console.WriteLine($"coding in c#",true);

           });
        //Delegateusinglongcutt();
        //Action<double> work = new Action<double>(
        //    (budget) =>
        //    {
        //        Console.WriteLine($"reg charges: {budget * 95 / 100}");

        //        Console.WriteLine($"reg charges: {budget * 5 / 100}");
        //    });
        Func<string,string> modifiedCompute = (a) => $":{a}";

        //modifiedCompute += (a,b) => $"subtraction:{n1 - n2}";

        //Func<int, int, string> modifiedCompute = (n1, n2) => $"Addition:{n1 + n2}";
        //modifiedCompute += (n1, n2) => $"subtraction:{n1 - n2}";

        //Predicate<string,bool> isActive = (v) =>
        //{
        //    if (v == 0) return false;
        //    else return true;
        //};
        //working();
        //Console.WriteLine(modifiedCompute(100, 200));
        //Console.WriteLine($"output:{isActive(1)}");
        Predicate<string> isActive = (a) =>
        {
            if (a == null) return false;
            else return true;
        };
        //rockyrani(50000d);
        Console.WriteLine($"dhanush");
        Console.WriteLine(isActive("jj"));
    }
}



//    private static void rockyrani()
//    {
//        Contractor Rockyranimarriage = new Contractor((b) => Console.WriteLine($"pandit charges:{b * 20 / 100}"));
//        Rockyranimarriage += (b) => Console.WriteLine($"catering charges:{b * 50 / 100}");
//        Rockyranimarriage += (b) => Console.WriteLine($"mandap charges:{b * 5 / 100}");
//        Rockyranimarriage += (b) => Console.WriteLine($"porsche charges:{b * 15 / 100}");

//        Rockyranimarriage(50000000);
//    }

//    //instantiate

//    private static void usinglambda()
//        {
//            Compute objShortCompute = new Compute((a, b) => Console.WriteLine($"addition:{a + b}"));
//            objShortCompute += (s, t) => Console.WriteLine($"sub:{s - t}");
//            objShortCompute += (s, t) => Console.WriteLine($"multi:{s * t}");
//            objShortCompute += (s, t) => Console.WriteLine($"division:{s / t}");

//            objShortCompute(250, -50);




//        }

//    }


//static void SubFn(int n1, int n2)
//{
//    Console.WriteLine($"output of sub:{n1 - n2}");
//}


//static void MulFn(int n1, int n2)
//{
//    Console.WriteLine($"output of multiply:{n1 * n2}");
//}


//static void DivFn(int n1, int n2)

//{
//    Console.WriteLine($"output of divide:{n1 / n2}");
//}

//static void AddFn(int n1, int n2)
//{
//    Console.WriteLine($"output of add:{n1 + n2}");
//}
//}


      