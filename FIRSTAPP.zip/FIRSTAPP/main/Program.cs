﻿using emplib;
using EmpLib;


Person Rohith = new Person();
Rohith.Name = "Rohith";
Console.WriteLine(Rohith.Eat());

Person Rana = new Person();
Rana.Name = "Rana";
Console.WriteLine(Rana.Sleep());

Person Baap = new Employee() { Designation = "Intern", DOJ = DateTime.Now.AddMonths(-1) };
Baap.Name = "Baap";
((Employee)Baap).Designation = "Analyst";
Console.WriteLine(Baap.Work());
Console.WriteLine($"EmpId for {Baap.Name} is {((Employee)Baap).EmpId}");

Console.WriteLine(((Employee)Baap).AttendTraining("C2C"));

//polymorphism
RuntimePolymorphism Sharmaji = new RuntimePolymorphism();
Console.WriteLine($"Sharmaji:{Sharmaji.Settle()}");
Console.WriteLine($"Sharmaji gets married:{Sharmaji.GetMarried()}");

RuntimePolymorphism SharmajiKaBeta = new RuntimePolymorphism();
Console.WriteLine($"Sharmaji:{SharmajiKaBeta.Settle()}");
Console.WriteLine($"Sharmaji gets married:{SharmajiKaBeta.GetMarried()}");

RuntimePolymorphism SharmaJiKaBeta2 = new Child();
Console.WriteLine($"SharmajiKaBeta2 gets married:{((Child)SharmaJiKaBeta2).GetMarried()}");
Console.WriteLine($"Sharmaji ka drawing concept (Using Abstract):{Sharmaji.Drawing()}");
Console.WriteLine($"Sharmaji ka dating concept (Using Abstract):{Sharmaji.WhatIsDating()}");

Employee Vidya = new Employee();
Vidya.Name = "Vidya";
Vidya.Designation = "Hacking";
Console.WriteLine(Vidya.Work());
Console.WriteLine(Vidya.Work("Hacking websites"));


Employee Srikar = new Employee();
Srikar.Name = "Srikar";
Srikar.SetTaxInfo("Im eligible in the 20% tax payer category");
Console.WriteLine(Srikar.GetTaxInfo());


Person SriRam = new Person("ASFSD79878765", "+91 9876543210");

Console.WriteLine($"Aadhar:{SriRam.Aadhar}| Mobile Number:{SriRam.Mobile}");