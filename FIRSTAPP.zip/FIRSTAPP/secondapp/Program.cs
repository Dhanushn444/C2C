﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World! is bullshit");
Console.WriteLine("add these no" + (5+5));
